#!/bin/sh
cd csd
zip testcases.zip *