#include <bits/stdc++.h>
using namespace std;

int main(int argc,char **argv){
    int id = atoi(argv[1]);
    printf("%d",id);
    return 0;
}